const express = require('express');
const router = express.Router();
const { getSubjects, createSubject } = require('../controllers/subject.controller');

// Rutas correctas
router.get('/subjects', getSubjects);
router.post('/subjects', createSubject);

module.exports = router;
