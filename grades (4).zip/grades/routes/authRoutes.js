// utils/mailer.js debe estar bien configurado antes de usar esto

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { sendMail } = require('../utils/mailer');

// Página de login
router.get('/login', (req, res) => {
  res.render('login');
});

// Página de registro
router.get('/register', (req, res) => {
  res.render('register');
});

// Registrar usuario con correo de bienvenida
router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  const hashed = await bcrypt.hash(password, 10);
  const user = new User({ username, password: hashed });
  await user.save();

  await sendMail(
    username,
    '¡Bienvenida a Grades!',
    `<h2>Hola ${username}</h2><p>Gracias por registrarte en nuestra app.</p>`
  );

  res.redirect('/login');
});

// Iniciar sesión con alerta de inicio
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.redirect('/login');

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.redirect('/login');

  req.session.userId = user._id;

  await sendMail(
    username,
    '🔔 Alerta de inicio de sesión',
    `<p>Hola ${username}, alguien inició sesión en tu cuenta hace unos momentos.</p>`
  );

  res.redirect('/dashboard');
});

// Cerrar sesión
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});


// 🔧 Ruta de prueba de envío de correo
router.get('/test-email', async (req, res) => {
  try {
    await sendMail(
      'robertokeyjarl@gmail.com',
      '📬 Correo de prueba desde Grades',
      '<h2>¡Hola!</h2><p>Este es un correo de prueba para verificar el envío desde tu app.</p>'
    );
    res.send('✅ Correo de prueba enviado correctamente.');
  } catch (err) {
    console.error(err);
    res.send('❌ Error al enviar correo de prueba.');
  }
});

module.exports = router;
