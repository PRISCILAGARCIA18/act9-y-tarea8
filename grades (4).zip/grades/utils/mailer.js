const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

const sendMail = async (to, subject, html) => {
  const options = {
    from: `"Grades App" <${process.env.EMAIL_USER}>`,
    to,
    subject,
    html
  };

  try {
    await transporter.sendMail(options);
    console.log(`📤 Email enviado a ${to}`);
  } catch (error) {
    console.error('❌ Error al enviar email:', error);
  }
};

module.exports = { sendMail };
