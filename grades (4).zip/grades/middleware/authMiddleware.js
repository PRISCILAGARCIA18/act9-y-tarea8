// middleware/authMiddleware.js

function isAuthenticated(req, res, next) {
    if (req.session && req.session.userId) {
      return next(); // El usuario está logueado
    }
    res.redirect('/login'); // Redirige al login si no está logueado
  }
  
  module.exports = { isAuthenticated };
  