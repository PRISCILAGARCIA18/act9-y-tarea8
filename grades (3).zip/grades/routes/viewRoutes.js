const express = require('express');
const router = express.Router();
const { isAuthenticated } = require('../middleware/authMiddleware');
const User = require('../models/User'); // Asegúrate que esta línea está

// Vista pública
router.get('/', (req, res) => {
  res.render('landingpage');
});

// Vista protegida
router.get('/dashboard', isAuthenticated, async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);
    res.render('dashboard', { user });
  } catch (error) {
    console.error('Error al cargar el dashboard:', error);
    res.redirect('/login');
  }
});

module.exports = router;
