const express = require('express');
const router = express.Router();
const { getActivities, createActivity } = require('../controllers/activity.controller');

// Ruta para obtener todas las actividades
router.get('/', getActivities);

// Ruta para obtener actividades de una materia específica
router.get('/:subjectId', getActivities);

// Ruta para agregar una actividad
router.post('/', createActivity);

module.exports = router;
