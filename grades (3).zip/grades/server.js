const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const path = require('path');
require('dotenv').config();

const app = express();

// Conexión a MongoDB
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB Connected'))
.catch((err) => console.error('Error de conexión a MongoDB:', err));

// Middlewares
app.use(express.urlencoded({ extended: true }));
app.use(express.json()); // <-- Necesario para leer JSON del frontend
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configurar sesión
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}));

// Variable global para saber si hay sesión
app.use((req, res, next) => {
  res.locals.userId = req.session.userId;
  next();
});

// Rutas
const authRoutes = require('./routes/authRoutes');
const viewRoutes = require('./routes/viewRoutes');
const subjectRoutes = require('./routes/subject.routes');
const activityRoutes = require('./routes/activity.routes');

app.use('/', authRoutes);
app.use('/', viewRoutes);
app.use('/', subjectRoutes);
app.use('/', activityRoutes);

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor en http://localhost:${PORT}`);
});
